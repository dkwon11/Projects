//
//  TodaysFitViewController.swift
//  LitFit-Swipe1
//
//  Created by labuser on 7/22/18.
//  Copyright © 2018 David Kwon. All rights reserved.
//

import UIKit
import Firebase
import FirebaseFirestore
import FirebaseStorage
import FirebaseAuth

class TodaysFitViewController: UIViewController, UICollectionViewDelegate, UICollectionViewDataSource {
    
    var classArray : [getInspiredPost] = []
    var imageURL : [String] = []
    let db = Firestore.firestore()
    var filterOccasion : String = "All"
    @IBOutlet weak var filterOutlet: UIButton!
    @IBOutlet weak var spinnerOutlet: UIActivityIndicatorView!
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        let detailedVC : getInspiredDetailedViewController = self.storyboard?.instantiateViewController(withIdentifier: "getInspiredDetailed") as! getInspiredDetailedViewController
        detailedVC.currentPost = classArray[indexPath.item]
        self.present(detailedVC, animated: true)
    }
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return classArray.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "topCell", for: indexPath)
        let cellImage : UIImageView = UIImageView(frame: CGRect(x: cell.bounds.minX, y: cell.bounds.minY, width: cell.bounds.width, height: cell.bounds.height))
        cellImage.image = classArray[indexPath.item].image
        cell.addSubview(cellImage)
        let backgroundView : UIView = UIView(frame: CGRect(x: cell.bounds.minX, y: 4 * (cell.bounds.maxY/5), width: cell.bounds.width, height: cell.bounds.height/5))
        backgroundView.backgroundColor = UIColor.black
        backgroundView.alpha = 0.3
        cell.addSubview(backgroundView)
        let occasionLabel : UILabel = UILabel(frame: CGRect(x: cell.bounds.minX + 20, y: 4 * (cell.bounds.maxY/5), width: cell.bounds.width/2 + 20, height: cell.bounds.height/5))
        occasionLabel.textColor = UIColor.white
        occasionLabel.textAlignment = NSTextAlignment.left
        occasionLabel.text = classArray[indexPath.item].occasion
        cell.addSubview(occasionLabel)
        let likeLabel : UILabel = UILabel(frame: CGRect(x: cell.bounds.midX, y: 4 * (cell.bounds.maxY/5), width: cell.bounds.width/2 - 20, height: cell.bounds.height/5))
        likeLabel.textColor = UIColor.white
        likeLabel.textAlignment = NSTextAlignment.right
        likeLabel.text = "Likes: " + String(classArray[indexPath.item].likes)
        cell.addSubview(likeLabel)
        return cell
    }
    
    @IBOutlet weak var myCollectionView: UICollectionView!
    
    func getData(){
        classArray = []
        if filterOccasion == "All"{
                filterOutlet.setTitle("Filter", for: UIControlState.normal)
        } else{
                   filterOutlet.setTitle(filterOccasion, for: UIControlState.normal)
        }
        db.collection("inspiredPost").getDocuments() { (querySnapshot, err) in
            if let err = err {
                print("Error getting documents: \(err)")
            } else {
                self.spinnerOutlet.startAnimating()
                DispatchQueue.global().async {
                    for document in querySnapshot!.documents {
                        let tempOccasion = (document.data()["occasion"] as! String)
                        let tempLikes = (document.data()["likes"] as! Int)
                        let tempPostID = (document.data()["postID"] as! String)
                        let tempUserID = (document.data()["userId"] as! String)
                        let tempGender = document.data()["gender"] as! String
                        let tempAge = document.data()["age"] as! Int
                        let currentImageURL : String = document.data()["image"] as! String
                        self.imageURL.append(currentImageURL)
                        let tempDescription = (document.data()["description"] as! String)
                        do {
                            let url = URL(string: currentImageURL)
                            let data = try Data(contentsOf: url!)
                            let tempImage = UIImage(data: data)!
                            let tempInspiredClass : getInspiredPost = getInspiredPost(image: tempImage, description: tempDescription, occasion: tempOccasion, likes: tempLikes, postID: tempPostID, userID: tempUserID, age: tempAge, gender : tempGender, addedTime : nil)
                            if tempOccasion == self.filterOccasion || self.filterOccasion == "All"{
                                self.classArray.append(tempInspiredClass)
                            }
                        }
                        catch{
                            print("image error")
                        }
                    }
                    DispatchQueue.main.async {
                        self.spinnerOutlet.stopAnimating()
                        self.classArray = self.classArray.sorted(by: { $0.likes > $1.likes})
                        self.myCollectionView.reloadData()
                    }
                }
            }
        }
    }
    
    override func viewWillAppear(_ animated: Bool) {
        filterOccasion = "All"
        getData()
    }
    
    @IBAction func filterAction(_ sender: Any) {
        let alertUser = UIAlertController(title: "Select Occasion", message: "", preferredStyle: .alert)
        let action1 = UIAlertAction(title: "Casual", style: .default) { (action:UIAlertAction) in
            self.filterOccasion = "Casual";
            self.getData()
        }
        let action2 = UIAlertAction(title: "Night Out", style: .default) { (action:UIAlertAction) in
            self.filterOccasion = "Night Out";
            self.getData();
        }
        let action3 = UIAlertAction(title: "Job Interview", style: .default) { (action:UIAlertAction) in
            self.filterOccasion = "Job Interview";
            self.getData();
        }
        let action4 = UIAlertAction(title: "Business Casual", style: .default) { (action:UIAlertAction) in
            self.filterOccasion = "Business Casual";
            self.getData();
        }
        let action5 = UIAlertAction(title: "Formal", style: .default) { (action:UIAlertAction) in
            self.filterOccasion = "Formal";
            self.getData();
        }
        let action6 = UIAlertAction(title: "Streetwear", style: .default) { (action:UIAlertAction) in
            self.filterOccasion = "Streetwear";
            self.getData();
        }
        let action7 = UIAlertAction(title: "All", style: .default) { (action:UIAlertAction) in
            self.filterOccasion = "All";
            self.getData();
        }
        
        alertUser.addAction(action7)
        alertUser.addAction(action1)
        alertUser.addAction(action2)
        alertUser.addAction(action3)
        alertUser.addAction(action4)
        alertUser.addAction(action5)
        alertUser.addAction(action6)
        self.present(alertUser, animated: true, completion: nil)
    }
    
    
    @IBAction func logoutAction(_ sender: Any) {
        do{
            try Auth.auth().signOut()
        } catch{
            print("LogOut Error")
            return
        }
        let loginVC: loginViewController  = self.storyboard?.instantiateViewController(withIdentifier: "loginView") as! loginViewController
        self.present(loginVC, animated: true)
    }
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        myCollectionView.dataSource = self
        myCollectionView.delegate = self
    }

    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        view.endEditing(true)
        super.touchesBegan(touches, with: event)
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
}
