//
//  getInspiredDetailedViewController.swift
//  LitFit-Swipe1
//
//  Created by labuser on 7/31/18.
//  Copyright © 2018 David Kwon. All rights reserved.
//

import UIKit
import Firebase
import FirebaseFirestore
import FirebaseStorage
import FirebaseAuth

class getInspiredDetailedViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {
    
    var currentPost : getInspiredPost?
    var commentArray : [String] = []
    var commentIdArray : [String] = []
    var commentOrderArray : [Int] = []
    var ref: DocumentReference? = nil
    let db = Firestore.firestore()
    
    @IBOutlet weak var titleOutlet: UILabel!
    @IBOutlet weak var occasionOutlet: UILabel!
    @IBOutlet weak var descriptionOutlet: UILabel!
    @IBOutlet weak var imageOUtlet: UIImageView!
    @IBOutlet weak var textboxOutlet: UITextField!
    @IBOutlet weak var myTableView: UITableView!
    @IBOutlet weak var likesOutlet: UILabel!
    @IBOutlet weak var likeButtonOutlet: UIButton!
    
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return commentArray.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = UITableViewCell(style: .subtitle, reuseIdentifier: "inspiredCommentCell")
        cell.textLabel?.text = commentIdArray[indexPath.item] + ": " + commentArray[indexPath.item]
        cell.textLabel?.font = UIFont(name: (cell.textLabel?.font.fontName)!, size: 10)
        cell.textLabel?.numberOfLines = 0
        cell.textLabel?.lineBreakMode = NSLineBreakMode.byWordWrapping
        return cell
    }
    
    @IBAction func likeAction(_ sender: Any) {
        DispatchQueue.global().async {
            let ref = self.db.collection("inspiredPost").document((self.currentPost?.postID)!)
            ref.updateData(["likes" : ((self.currentPost?.likes)! + 1)])
            let ref2 = self.db.collection("userInfo").document((Auth.auth().currentUser?.email)!)
            ref2.getDocument { (querySnapshot, err) in
                if let err = err {
                    print("Error getting documents: \(err)")
                } else{
                    var arrayHolder : [String] = querySnapshot?.data()!["ratedPosts"] as! [String]
                    arrayHolder.append((self.currentPost?.postID)!)
                    ref2.updateData(["ratedPosts" : arrayHolder])
                }
            }
            DispatchQueue.main.async {
                let backVC: TodaysFitViewController  = self.storyboard?.instantiateViewController(withIdentifier: "todaysView") as! TodaysFitViewController
                self.present(backVC, animated: true)
            }
        }
    }
    
    @IBAction func commentButtonAction(_ sender: Any) {
        if textboxOutlet.text != ""{
            let currentUser : String = (Auth.auth().currentUser?.email)!
            self.ref = self.db.collection((currentPost?.postID)!).document()
            self.ref?.setData([
                "userId": currentUser,
                "comment": textboxOutlet.text!,
                "commentOrder": commentArray.count + 1
            ]){ err in
                if let err = err {
                    print("Error adding document: \(err)")
                }
                self.getComments()
                self.textboxOutlet.text = ""
            }
        } else{
            let alertUser = UIAlertController(title: "Comment can't be empty!", message: "", preferredStyle: .alert)
            let myAction = UIAlertAction(title: "Ok.", style: .default) { (action:UIAlertAction) in
                return;
            }
            alertUser.addAction(myAction)
            self.present(alertUser, animated: true, completion: nil)
        }
    }
    
    func getComments(){
        commentIdArray = []
        commentOrderArray = []
        commentArray = []
        db.collection((currentPost?.postID)!).getDocuments() { (querySnapshot, err) in
            if let err = err {
                print("Error getting documents: \(err)")
            } else {
                DispatchQueue.global().async {
                    for document in querySnapshot!.documents {
                        self.commentIdArray.append(document.data()["userId"] as! String)
                        self.commentArray.append(document.data()["comment"] as! String)
                        self.commentOrderArray.append(document.data()["commentOrder"] as! Int)
                    }
                    self.sortComments()
                    DispatchQueue.main.async {
                        self.myTableView.reloadData()
                    }
                }
            }
        }
    }
    
    func setupView(){
        occasionOutlet.text = currentPost?.occasion
        if currentPost?.description == ""{
            descriptionOutlet.text = "Description not provided"
            descriptionOutlet.textColor = UIColor.gray
        } else{
            descriptionOutlet.text = currentPost?.description
            descriptionOutlet.textColor = UIColor.black
        }
        imageOUtlet.image = currentPost?.image
        let likesInt = currentPost?.likes
        likesOutlet.text = String(likesInt!) + " Likes"
        titleOutlet.text = (currentPost?.userID)! + "'s Fit"
    }
    
    func sortComments(){
        var tempIDArray = commentIdArray
        var tempCommentArray = commentArray
        var tempCounter : Int = 0
        for currentOrder in commentOrderArray{
            tempIDArray[commentArray.count - currentOrder] = commentIdArray[tempCounter]
            tempCommentArray[commentArray.count - currentOrder] = commentArray[tempCounter]
            tempCounter = tempCounter + 1
        }
        commentIdArray = tempIDArray
        commentArray = tempCommentArray
    }
    
    @IBAction func backAction(_ sender: Any) {
        let backVC: TodaysFitViewController  = self.storyboard?.instantiateViewController(withIdentifier: "todaysView") as! TodaysFitViewController
        self.present(backVC, animated: true)
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        myTableView.delegate = self
        myTableView.dataSource = self
        myTableView.register(UITableViewCell.self, forCellReuseIdentifier: "inspiredCommentCell")
        myTableView.rowHeight = 25
        checkLiked()
        setupView()
        getComments()
    }
    
    func checkLiked(){
        var arrayHolder : [String] = []
        DispatchQueue.main.async {
            let ref3 = self.db.collection("userInfo").document((Auth.auth().currentUser?.email)!)
            ref3.getDocument { (querySnapshot, err) in
                if let err = err {
                    print("Error getting documents: \(err)")
                } else{
                    arrayHolder = querySnapshot?.data()!["ratedPosts"] as! [String]
                }
                if arrayHolder.contains((self.currentPost?.postID)!) || self.currentPost?.userID == Auth.auth().currentUser?.email{
                    self.likeButtonOutlet.isHidden = true
                } else{
                    self.likeButtonOutlet.isHidden = false
                }
            }
        }
    }
    
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        view.endEditing(true)
        super.touchesBegan(touches, with: event)
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
}
