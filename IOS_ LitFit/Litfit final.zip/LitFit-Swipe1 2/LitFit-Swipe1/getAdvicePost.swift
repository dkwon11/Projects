//
//  getAdvicePost.swift
//  LitFit-Swipe1
//
//  Created by labuser on 7/24/18.
//  Copyright © 2018 David Kwon. All rights reserved.
//

import Foundation
import UIKit
import Firebase

struct getAdvicePost {
    let image : UIImage
    let title : String
    let description : String
    let occasion : String
    let postID : String
    let userID : String
    let resolved : String
    let imageURLS : [String]
    let addedTime : Date?
}
