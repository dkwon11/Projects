//
//  getInspiredRateViewController.swift
//  LitFit-Swipe1
//
//  Created by labuser on 7/22/18.
//  Copyright © 2018 David Kwon. All rights reserved.
//

import UIKit
import Firebase
import FirebaseFirestore
import FirebaseStorage
import FirebaseAuth

class getInspiredRateViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {

    var classArray : [getInspiredPost] = []
    var swipeCounter : Int = 0
    var ref: DocumentReference? = nil
    let db = Firestore.firestore()
    var arrayHolder : [String] = []
    var commentArray : [String] = []
    var commentIdArray : [String] = []
    var commentOrderArray : [Int] = []
    
    
    @IBOutlet weak var indicatorLabel: UILabel!
    @IBOutlet weak var spinnerOutlet: UIActivityIndicatorView!
    @IBOutlet weak var commentPostOutlet: UIButton!
    @IBOutlet weak var commentTextOutlet: UITextField!
    @IBOutlet weak var imageOutlet: UIImageView!
    @IBOutlet weak var descriptionOutlet: UITextView!
    @IBOutlet weak var usernameOutlet: UILabel!
    @IBOutlet weak var GenAgeOutlet: UILabel!
    @IBOutlet weak var likeOutlet: UILabel!
    @IBOutlet weak var myTableView: UITableView!
    @IBOutlet weak var commentButtonOutlet: UIButton!
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return commentArray.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = UITableViewCell(style: .subtitle, reuseIdentifier: "commentCellRef")
        cell.textLabel?.text = commentIdArray[indexPath.item] + ": " + commentArray[indexPath.item]
        cell.textLabel?.font = UIFont(name: (cell.textLabel?.font.fontName)!, size: 10)
        return cell
    }
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        tableSetup()
        gestureSetup()
    }
    
    func tableSetup(){
        myTableView.dataSource = self
        myTableView.delegate = self
        myTableView.isHidden = true
        myTableView.register(UITableViewCell.self, forCellReuseIdentifier: "commentCellRef")
        myTableView.rowHeight = 20
    }
    
    override func viewWillAppear(_ animated: Bool) {
        commentButtonOutlet.setTitle("Comments", for: UIControlState.normal)
        commentPostOutlet.isHidden = true
        commentTextOutlet.isHidden = true
        myTableView.isHidden = true
        swipeCounter = 0
        classArray = []
        DispatchQueue.global().async {
            let ref2 = self.db.collection("userInfo").document((Auth.auth().currentUser?.email)!)
            ref2.getDocument { (querySnapshot, err) in
                if let err = err {
                    print("Error getting documents: \(err)")
                } else{
                    self.arrayHolder = querySnapshot?.data()!["ratedPosts"] as! [String]
                }
            }
            DispatchQueue.main.async {
                self.getData()
            }
        }
    }
    
    @IBAction func backAction(_ sender: Any) {
        self.dismiss(animated: true, completion: nil)
    }
    func getData(){
        db.collection("inspiredPost").getDocuments() { (querySnapshot, err) in
            if let err = err {
                print("Error getting documents: \(err)")
            } else {
                self.spinnerOutlet.startAnimating()
                DispatchQueue.global().async {
                    for document in querySnapshot!.documents {
                        let tempOccasion = (document.data()["occasion"] as! String)
                        let tempLikes = (document.data()["likes"] as! Int)
                        let tempPostID = (document.data()["postID"] as! String)
                        let tempUserID = (document.data()["userId"] as! String)
                        let tempGender = document.data()["gender"] as! String
                        let tempAge = document.data()["age"] as! Int
                        let currentImageURL : String = document.data()["image"] as! String
                        let tempDescription = (document.data()["description"] as! String)
                        let tempAddedTime = document.data()["timeStamp"] as! Date
                        
                        if !self.arrayHolder.contains(tempPostID) && Auth.auth().currentUser?.email != tempUserID{
                            do {
                                let url = URL(string: currentImageURL)
                                let data = try Data(contentsOf: url!)
                                let tempImage = UIImage(data: data)!
                                let tempInspiredClass : getInspiredPost = getInspiredPost(image: tempImage, description: tempDescription, occasion: tempOccasion, likes: tempLikes, postID: tempPostID, userID: tempUserID, age: tempAge, gender : tempGender, addedTime: tempAddedTime)
                                self.classArray.append(tempInspiredClass)
                            }
                            catch{
                                print("image error")
                            }
                        }
                    }
                    DispatchQueue.main.async {
                        self.spinnerOutlet.stopAnimating()
                        self.reloadData()
                    }
                }
            }
        }
    }
    
    func reloadData(){
        if classArray.count == 0{
            let alertUser = UIAlertController(title: "There are no more fits to rate! Please try again later.", message: "", preferredStyle: .alert)
            let myAction = UIAlertAction(title: "Ok.", style: .default) { (action:UIAlertAction) in
                let backVC: TodaysFitViewController  = self.storyboard?.instantiateViewController(withIdentifier: "todaysView") as! TodaysFitViewController
                self.present(backVC, animated: true)
            }
            alertUser.addAction(myAction)
            self.present(alertUser, animated: true, completion: nil)
        } else{
            self.classArray = self.classArray.sorted(by: { $0.addedTime! < $1.addedTime! })
            imageOutlet.image = classArray[swipeCounter].image
            if classArray[swipeCounter].description == ""{
                descriptionOutlet.text = "Description not provided"
                descriptionOutlet.textColor = UIColor.gray
            } else{
                descriptionOutlet.text = classArray[swipeCounter].description
                descriptionOutlet.textColor = UIColor.black
            }
            usernameOutlet.text = classArray[swipeCounter].userID
            var convertGender : String = ""
            if classArray[swipeCounter].gender == "male"{
                convertGender = "M"
            } else{
                convertGender = "F"
            }
            GenAgeOutlet.text = convertGender + " " + String(classArray[swipeCounter].age)
            likeOutlet.text = String(classArray[swipeCounter].likes) + " Likes"
        }
    }
    
    func gestureSetup(){
        let swipeRight = UISwipeGestureRecognizer(target: self, action: #selector(getInspiredRateViewController.respondToSwipeGesture(gesture:)))
        swipeRight.direction = .right
        view.addGestureRecognizer(swipeRight)
        
        let swipeLeft = UISwipeGestureRecognizer(target: self, action: #selector(getInspiredRateViewController.respondToSwipeGesture(gesture:)))
        swipeLeft.direction = .left
        view.addGestureRecognizer(swipeLeft)
    }
    
    @objc func respondToSwipeGesture(gesture: UIGestureRecognizer) {
        if let swipeGesture = gesture as? UISwipeGestureRecognizer {
            switch swipeGesture.direction {
            case UISwipeGestureRecognizerDirection.right:
                swipeRight()
            case UISwipeGestureRecognizerDirection.left:
                swipeLeft()
            default:
                break
            }
        }
    }
    
    func getComments(){
        commentIdArray = []
        commentOrderArray = []
        commentArray = []
        db.collection(classArray[swipeCounter].postID).getDocuments() { (querySnapshot, err) in
            if let err = err {
                print("Error getting documents: \(err)")
            } else {
                DispatchQueue.global().async {
                    for document in querySnapshot!.documents {
                        self.commentIdArray.append(document.data()["userId"] as! String)
                        self.commentArray.append(document.data()["comment"] as! String)
                        self.commentOrderArray.append(document.data()["commentOrder"] as! Int)
                    }
                    self.sortComments()
                    DispatchQueue.main.async {
                        self.myTableView.reloadData()
                    }
                }
            }
        }
    }
    
    func sortComments(){
        var tempIDArray = commentIdArray
        var tempCommentArray = commentArray
        var tempCounter : Int = 0
        for currentOrder in commentOrderArray{
            tempIDArray[commentArray.count - currentOrder] = commentIdArray[tempCounter]
            tempCommentArray[commentArray.count - currentOrder] = commentArray[tempCounter]
            tempCounter = tempCounter + 1
        }
        commentIdArray = tempIDArray
        commentArray = tempCommentArray
    }
    
    @IBAction func commentAction(_ sender: Any) {
        if commentButtonOutlet.titleLabel?.text == "Comments"{
            getComments()
            commentButtonOutlet.setTitle("Close Comments", for: UIControlState.normal)
            commentPostOutlet.isHidden = false
            commentTextOutlet.isHidden = false
            myTableView.isHidden = false
        } else {
            commentButtonOutlet.setTitle("Comments", for: UIControlState.normal)
            commentPostOutlet.isHidden = true
            commentTextOutlet.isHidden = true
            myTableView.isHidden = true
        }
    }
    
    @IBAction func commentPostAction(_ sender: Any) {
        if commentTextOutlet.text != ""{
            let currentUser : String = (Auth.auth().currentUser?.email)!
            self.ref = self.db.collection(classArray[swipeCounter].postID).document()
            self.ref?.setData([
                "userId": currentUser,
                "comment": commentTextOutlet.text!,
                "commentOrder": commentArray.count + 1
            ]){ err in
                if let err = err {
                    print("Error adding document: \(err)")
                }
                self.getComments()
                self.commentTextOutlet.text = ""
            }
        } else{
            let alertUser = UIAlertController(title: "Comment can't be empty!", message: "", preferredStyle: .alert)
            let myAction = UIAlertAction(title: "Ok.", style: .default) { (action:UIAlertAction) in
                return;
            }
            alertUser.addAction(myAction)
            self.present(alertUser, animated: true, completion: nil)
        }
    }
    
    
    func swipeRight(){
        indicatorLabel.text = "Liked!"
        UIView.animate(withDuration: 0.33, animations: {
            self.indicatorLabel.alpha = 0.0
        }) { (true) in
            self.indicatorLabel.text = ""
            self.indicatorLabel.alpha = 1.0
        }
        swipeCounter = swipeCounter + 1
        let ref = self.db.collection("inspiredPost").document(classArray[swipeCounter-1].postID)
        ref.updateData(["likes" : (classArray[swipeCounter-1].likes + 1)])
        let ref2 = self.db.collection("userInfo").document((Auth.auth().currentUser?.email)!)
        ref2.getDocument { (querySnapshot, err) in
            if let err = err {
                print("Error getting documents: \(err)")
            } else{
                var arrayHolder : [String] = querySnapshot?.data()!["ratedPosts"] as! [String]
                arrayHolder.append(self.classArray[self.swipeCounter-1].postID)
                ref2.updateData(["ratedPosts" : arrayHolder])
            }
        }
        if swipeCounter > classArray.count - 1{
            emptyPage()
        } else{
            reloadData()
        }
    }
    
    func swipeLeft(){
        indicatorLabel.text = "Skipped!"
        UIView.animate(withDuration: 0.33, animations: {
            self.indicatorLabel.alpha = 0.0
        }) { (true) in
            self.indicatorLabel.text = ""
            self.indicatorLabel.alpha = 1.0
        }
        swipeCounter = swipeCounter + 1
        let ref2 = self.db.collection("userInfo").document((Auth.auth().currentUser?.email)!)
        ref2.getDocument { (querySnapshot, err) in
            if let err = err {
                print("Error getting documents: \(err)")
            } else{
                var arrayHolder : [String] = querySnapshot?.data()!["ratedPosts"] as! [String]
                arrayHolder.append(self.classArray[self.swipeCounter-1].postID)
                ref2.updateData(["ratedPosts" : arrayHolder])
            }
        }
        if swipeCounter > classArray.count - 1{
            emptyPage()
        } else {
            reloadData()
        }
    }
    
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        view.endEditing(true)
        super.touchesBegan(touches, with: event)
    }
    
    func emptyPage(){
        let alertUser = UIAlertController(title: "There are no more fits to rate! Please try again later.", message: "", preferredStyle: .alert)
        let myAction = UIAlertAction(title: "Ok.", style: .default) { (action:UIAlertAction) in
            let backVC: TodaysFitViewController  = self.storyboard?.instantiateViewController(withIdentifier: "todaysView") as! TodaysFitViewController
            self.present(backVC, animated: true)
        }
        alertUser.addAction(myAction)
        self.present(alertUser, animated: true, completion: nil)
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
}
