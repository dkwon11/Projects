//
//  getAdvicePostViewController.swift
//  LitFit-Swipe1
//
//  Created by labuser on 7/22/18.
//  Copyright © 2018 David Kwon. All rights reserved.
//

import UIKit
import Firebase
import FirebaseFirestore
import FirebaseStorage
import FirebaseAuth


class getAdvicePostViewController: UIViewController, UIImagePickerControllerDelegate, UINavigationControllerDelegate, UICollectionViewDataSource, UICollectionViewDelegate {
    
    var imageArray : [UIImage] = []
    var downloadURLs : [String] = []
    var imageBool : Bool = false
    var currentImage : UIImage?
    var currentIndex : Int?
    var ref: DocumentReference? = nil
    let db = Firestore.firestore()
    let storage = Storage.storage()
    
    var currentOccasion : String = "" {
        didSet{
            occasionTextBox.text = currentOccasion
        }
    }
    
    @IBOutlet weak var addButton: UIButton!
    @IBOutlet weak var imagePreview: UIImageView!
    @IBOutlet weak var myCollectionView: UICollectionView!
    @IBOutlet weak var occasionTextBox: UITextField!
    @IBOutlet var descriptionOutlet: UITextView!
    @IBOutlet weak var titleOutlet: UITextView!
    @IBOutlet weak var spinnerOutlet: UIActivityIndicatorView!
    
    @IBAction func getAdvicePostAction(_ sender: Any) {
        if !imageArray.isEmpty{
            if titleOutlet.text! == ""{
                let alertUser = UIAlertController(title: "You need a title for your post!", message: "", preferredStyle: .alert)
                let myAction = UIAlertAction(title: "Ok.", style: .default) { (action:UIAlertAction) in
                    return;
                }
                alertUser.addAction(myAction)
                self.present(alertUser, animated: true, completion: nil)
            } else if currentOccasion == ""{
                let alertUser = UIAlertController(title: "You need to specify an occasion for your fit.", message: "", preferredStyle: .alert)
                let myAction = UIAlertAction(title: "Ok.", style: .default) { (action:UIAlertAction) in
                    return;
                }
                alertUser.addAction(myAction)
                self.present(alertUser, animated: true, completion: nil)
            } else{
                uploadData()
            }
        } else{
            let noImageAlert = UIAlertController(title: "You need to upload atleast one photo!", message: "", preferredStyle: .alert)
            let imageAction = UIAlertAction(title: "Ok.", style: .default) { (action:UIAlertAction) in
                return;
            }
            noImageAlert.addAction(imageAction)
            self.present(noImageAlert, animated: true, completion: nil)
        }
    }
    
    func uploadData(){
        spinnerOutlet.startAnimating()
        let storageRef = storage.reference()
        var counter : Int = 0
        let uniqueID = NSUUID().uuidString
        for image in self.imageArray{
            let data : Data = UIImageJPEGRepresentation(image, 0.5)!
            let counterString = String(counter)
            let imageRef = storageRef.child("/" + uniqueID + "/" + counterString + ".jpg")
            counter = counter + 1
            let uploadTask = imageRef.putData(data, metadata: nil) { (metadata, error) in
                guard let metadata = metadata else {
                    return
                }
                let size = metadata.size
                imageRef.downloadURL { (url, error) in
                    guard let downloadURL = url else {
                        return
                    }
                    self.downloadURLs.append(downloadURL.absoluteString)
                    if self.downloadURLs.count == self.imageArray.count{
                        let userName : String = (Auth.auth().currentUser?.email)!
                        self.ref = self.db.collection("advicePost").document()
                        let myKey = self.ref?.documentID
                        self.ref?.setData(["userId": userName,
                            "title": self.titleOutlet.text!,
                            "images": self.downloadURLs,
                            "postID": myKey!,
                            "description": self.descriptionOutlet.text!,
                            "occasion": self.currentOccasion,
                            "resolved": "no",
                            "timeStamp": FieldValue.serverTimestamp()
                            ]
                        ){ err in
                                if let err = err {
                                    print("Error adding document: \(err)")
                                } else {
                                    self.spinnerOutlet.stopAnimating()
                                    let detailedVC: getAdviceViewController  = self.storyboard?.instantiateViewController(withIdentifier: "getAdviceView") as! getAdviceViewController
                                    self.present(detailedVC, animated: true)
                                }
                        }
                    }
                }
            }
        }
    }
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        setup()
    }
    
    func setup(){
        myCollectionView.dataSource = self
        myCollectionView.delegate = self
    }
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return imageArray.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "adviceCell", for: indexPath)
        let cellImage : UIImageView = UIImageView(frame: CGRect(x: cell.bounds.minX, y: cell.bounds.minY, width: cell.bounds.width, height: cell.bounds.height))
        cellImage.image = imageArray[indexPath.item]
        cell.addSubview(cellImage)
        return cell
    }
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        imagePreview.image = imageArray[indexPath.item]
        addButton.titleLabel?.text = "Delete"
        currentIndex = indexPath.item
    }
    
    @IBAction func takePhotoAction(_ sender: Any) {
        if imageArray.count >= 5{
            print("max 5")
            return
        }
        let picker = UIImagePickerController()
        picker.delegate = self
        picker.sourceType = .camera
        addButton.titleLabel?.text = "Add"
        present(picker, animated: true, completion: nil)
    }
    
    @IBAction func occasionTextAction(_ sender: Any) {
        alertOccasion()
    }
    
    @IBAction func occasionAction(_ sender: Any) {
        alertOccasion()
    }
    
    @IBAction func photoLibraryAction(_ sender: Any) {
        if imageArray.count >= 5{
            print("max 5")
            return
        }
        let picker = UIImagePickerController()
        picker.delegate = self
        picker.sourceType = .photoLibrary
        addButton.titleLabel?.text = "Add"
        present(picker, animated: true, completion: nil)
    }
    
    @IBAction func addAction(_ sender: Any) {
        if addButton.titleLabel?.text == "Delete"{
            imageArray.remove(at: currentIndex!)
            addButton.titleLabel?.text = "Add"
            imagePreview.image = UIImage.init()
            myCollectionView.reloadData()
        } else{
            if imageBool == true{
                imageArray.append(currentImage!)
                imagePreview.image = UIImage.init()
                myCollectionView.reloadData()
                imageBool = false
            }
        }
    }
    
    func alertOccasion(){
        let alertUser = UIAlertController(title: "Select Occasion", message: "", preferredStyle: .alert)
        let action1 = UIAlertAction(title: "Casual", style: .default) { (action:UIAlertAction) in
            self.currentOccasion = "Casual";
        }
        let action2 = UIAlertAction(title: "Night Out", style: .default) { (action:UIAlertAction) in
            self.currentOccasion = "Night Out";
        }
        let action3 = UIAlertAction(title: "Job Interview", style: .default) { (action:UIAlertAction) in
            self.currentOccasion = "Job Interview";
        }
        let action4 = UIAlertAction(title: "Business Casual", style: .default) { (action:UIAlertAction) in
            self.currentOccasion = "Business Casual";
        }
        let action5 = UIAlertAction(title: "Formal", style: .default) { (action:UIAlertAction) in
            self.currentOccasion = "Formal";
        }
        let action6 = UIAlertAction(title: "Streetwear", style: .default) { (action:UIAlertAction) in
            self.currentOccasion = "Streetwear";
        }
        alertUser.addAction(action1)
        alertUser.addAction(action2)
        alertUser.addAction(action3)
        alertUser.addAction(action4)
        alertUser.addAction(action5)
        alertUser.addAction(action6)
        self.present(alertUser, animated: true, completion: nil)
    }
    
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [String : Any]) {
        let imageHolder = info[UIImagePickerControllerOriginalImage] as? UIImage
        imagePreview.image = imageHolder
        currentImage = imageHolder
        imageBool = true
        dismiss(animated: true, completion: nil)
    }
    
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        view.endEditing(true)
        super.touchesBegan(touches, with: event)
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
    @IBAction func unwind(_ sender: Any) {
        self.dismiss(animated: true, completion: nil)
    }
}
