//
//  getInspiredPostViewController.swift
//  LitFit-Swipe1
//
//  Created by labuser on 7/22/18.
//  Copyright © 2018 David Kwon. All rights reserved.
//

import UIKit
import Photos
import Firebase
import FirebaseFirestore
import FirebaseAuth
import FirebaseStorage

class getInspiredPostViewController: UIViewController, UIImagePickerControllerDelegate, UINavigationControllerDelegate {
    
    var currentOccasion : String = ""{
        didSet{
            occasionTextOutlet.text = currentOccasion
        }
    }
    
    var currentImage : UIImage?
    @IBOutlet weak var imagePreview: UIImageView!
    @IBOutlet weak var occasionTextOutlet: UITextField!
    @IBOutlet var descriptionOutlet: UITextView!
    @IBOutlet weak var spinnerOutlet: UIActivityIndicatorView!
    
    var userGender : String = ""
    var userAge : Int = 0
    var ref: DocumentReference? = nil
    let db = Firestore.firestore()
    let storage = Storage.storage()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        getGenderAge()
    }
    
    func getGenderAge(){
        let userRef = db.collection("userInfo").document((Auth.auth().currentUser?.email)!)
        userRef.getDocument { (querySnapShop, err) in
            if let err = err {
                print("Error getting documents: \(err)")
            } else {
               self.userGender = querySnapShop?.data()!["gender"] as! String
               self.userAge = querySnapShop?.data()!["age"] as! Int
            }
        }
    }
    
    @IBAction func backAction(_ sender: Any) {
        self.dismiss(animated: true, completion: nil)
    }
    
    func uploadData(){
        spinnerOutlet.startAnimating()
        let storageRef = storage.reference()
        let uniqueID = NSUUID().uuidString
        let data : Data = UIImageJPEGRepresentation(currentImage!, 0.5)!
        let imageRef = storageRef.child("/inspiredImages/" + uniqueID + ".jpg")
        _ = imageRef.putData(data, metadata: nil) { (metadata, error) in
            guard metadata != nil else {
                return
            }
            imageRef.downloadURL { (url, error) in
                guard url != nil else {
                    return
                }
                let userName : String = (Auth.auth().currentUser?.email)!
                self.ref = self.db.collection("inspiredPost").document()
                let myKey = self.ref?.documentID
                let likes : Int = 0
                let urlHolder : String = (url?.absoluteString)!
                self.ref?.setData([     "userId": userName,
                                        "image": urlHolder,
                                        "postID": myKey!,
                                        "likes": likes,
                                        "gender": self.userGender,
                                        "age": self.userAge,
                                        "description": self.descriptionOutlet.text!,
                                        "occasion": self.currentOccasion,
                                        "timeStamp": FieldValue.serverTimestamp()
                    ]){ err in
                    if let err = err {
                        print("Error adding document: \(err)")
                    } else {
                        self.spinnerOutlet.stopAnimating()
                        let backVC: TodaysFitViewController  = self.storyboard?.instantiateViewController(withIdentifier: "todaysView") as! TodaysFitViewController
                        self.present(backVC, animated: true)
                    }
                }
            }
        }
        
    }
    
    @IBAction func getInspiredPostAction(_ sender: Any) {
        if currentImage != nil{
            if currentOccasion == ""{
                let alertUser = UIAlertController(title: "You need to specify an occasion for your fit.", message: "", preferredStyle: .alert)
                let myAction = UIAlertAction(title: "Ok.", style: .default) { (action:UIAlertAction) in
                    return;
                }
                alertUser.addAction(myAction)
                self.present(alertUser, animated: true, completion: nil)
            } else{
                uploadData()
            }
        } else{
            let noImageAlert = UIAlertController(title: "We need a picture of you!", message: "", preferredStyle: .alert)
            let imageAction = UIAlertAction(title: "Ok.", style: .default) { (action:UIAlertAction) in
                return;
            }
            noImageAlert.addAction(imageAction)
            self.present(noImageAlert, animated: true, completion: nil)
        }
    }
    
    @IBAction func occasionButtonAction(_ sender: Any) {
        alertOccasion()
    }
    
    @IBAction func occasionTextAction(_ sender: Any) {
        alertOccasion()
    }
    
    @IBAction func takePhotoAction(_ sender: Any) {
        let picker = UIImagePickerController()
        picker.delegate = self
        picker.sourceType = .camera // replace with photoLibrary if you're using the simulator or else it'll throw an error.
        present(picker, animated: true, completion: nil)
    }
    
    func alertOccasion(){
        let alertUser = UIAlertController(title: "Select Occasion", message: "", preferredStyle: .alert)
        let action1 = UIAlertAction(title: "Casual", style: .default) { (action:UIAlertAction) in
            self.currentOccasion = "Casual";
        }
        let action2 = UIAlertAction(title: "Night Out", style: .default) { (action:UIAlertAction) in
            self.currentOccasion = "Night Out";
        }
        let action3 = UIAlertAction(title: "Job Interview", style: .default) { (action:UIAlertAction) in
            self.currentOccasion = "Job Interview";
        }
        let action4 = UIAlertAction(title: "Business Casual", style: .default) { (action:UIAlertAction) in
            self.currentOccasion = "Business Casual";
        }
        let action5 = UIAlertAction(title: "Formal", style: .default) { (action:UIAlertAction) in
            self.currentOccasion = "Formal";
        }
        let action6 = UIAlertAction(title: "Streetwear", style: .default) { (action:UIAlertAction) in
            self.currentOccasion = "Streetwear";
        }
        alertUser.addAction(action1)
        alertUser.addAction(action2)
        alertUser.addAction(action3)
        alertUser.addAction(action4)
        alertUser.addAction(action5)
        alertUser.addAction(action6)
        self.present(alertUser, animated: true, completion: nil)
    }
    
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        view.endEditing(true)
        super.touchesBegan(touches, with: event)
    }
    
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [String : Any]) {
        let myImage = info[UIImagePickerControllerOriginalImage] as? UIImage
        imagePreview.image = myImage
        currentImage = myImage
        dismiss(animated: true, completion: nil)
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
}
