//
//  signUpViewController.swift
//  LitFit-Swipe1
//
//  Created by labuser on 7/22/18.
//  Copyright © 2018 David Kwon. All rights reserved.
//

import UIKit
import Firebase
import FirebaseFirestore
import FirebaseStorage
import FirebaseAuth

class signUpViewController: UIViewController {
    
    
    var userGender : String = ""
    var userAge : Int?
    var ref: DocumentReference? = nil
    let db = Firestore.firestore()
    
    @IBOutlet weak var spinnerOutlet: UIActivityIndicatorView!
    @IBOutlet weak var emailOutlet: UITextField!
    @IBOutlet weak var passwordOutlet: UITextField!
    @IBOutlet weak var maleButtonOutlet: UIButton!
    @IBOutlet weak var femaleButtonOutlet: UIButton!
    @IBOutlet weak var ageOutlet: UITextField!
    
    @IBAction func maleAction(_ sender: Any) {
        maleButtonOutlet.alpha = 1.0
        femaleButtonOutlet.alpha = 0.2
        userGender = "male"
    }
    
    @IBAction func femaleAction(_ sender: Any) {
        femaleButtonOutlet.alpha = 1.0
        maleButtonOutlet.alpha = 0.2
        userGender = "female"
    }
    
    
    @IBAction func submitAction(_ sender: Any) {
        let email = emailOutlet.text
        let password = passwordOutlet.text
        if userGender == ""{
            let alertUser = UIAlertController(title: "You need to select your Gender.", message: "", preferredStyle: .alert)
            let myAction = UIAlertAction(title: "Ok.", style: .default) { (action:UIAlertAction) in
                return;
            }
            alertUser.addAction(myAction)
            self.present(alertUser, animated: true, completion: nil)
            return
        }
        if Int(ageOutlet.text!) == nil{
            let alertUser = UIAlertController(title: "Please specify your age.", message: "", preferredStyle: .alert)
            let myAction = UIAlertAction(title: "Ok.", style: .default) { (action:UIAlertAction) in
                return;
            }
            alertUser.addAction(myAction)
            self.present(alertUser, animated: true, completion: nil)
            return
        }
        spinnerOutlet.startAnimating()
        Auth.auth().createUser(withEmail: email!, password: password!) { (authResult, error) in
            guard let email = authResult?.user.email, error == nil else {
                let alertUser = UIAlertController(title: error?.localizedDescription, message: "", preferredStyle: .alert)
                let myAction = UIAlertAction(title: "Ok.", style: .default) { (action:UIAlertAction) in
                    self.spinnerOutlet.stopAnimating()
                    return;
                }
                alertUser.addAction(myAction)
                self.present(alertUser, animated: true, completion: nil)
                return
            }
            print("\(email) created")
            self.userAge = Int(self.ageOutlet.text!)
            self.ref = self.db.collection("userInfo").document(email)
            let tempArray : [String] = []
            self.ref?.setData([
                "userId": email,
                "gender": self.userGender,
                "age": self.userAge!,
                "ratedPosts": tempArray
            ]){ err in
                if let err = err {
                    print("Error adding document: \(err)")
                } else {
                    Auth.auth().signIn(withEmail: email, password: password!) { (user, error) in
                        if let error = error {
                            let alertUser = UIAlertController(title: error.localizedDescription, message: "", preferredStyle: .alert)
                            let myAction = UIAlertAction(title: "Ok.", style: .default) { (action:UIAlertAction) in
                                self.spinnerOutlet.stopAnimating()
                                return;
                            }
                            alertUser.addAction(myAction)
                            self.present(alertUser, animated: true, completion: nil)
                            return
                        }
                        self.spinnerOutlet.stopAnimating()
                        let newVC = self.storyboard?.instantiateViewController(withIdentifier: "todaysView")
                        self.present(newVC!, animated: true)
                    }
                }
            }

        }
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
    }

    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        view.endEditing(true)
        super.touchesBegan(touches, with: event)
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()

    }
}
