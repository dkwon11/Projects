//
//  getAdviceDetailedViewController.swift
//  LitFit-Swipe1
//
//  Created by labuser on 7/29/18.
//  Copyright © 2018 David Kwon. All rights reserved.
//

import UIKit
import Firebase
import FirebaseFirestore
import FirebaseStorage
import FirebaseAuth

class getAdviceDetailedViewController: UIViewController, UICollectionViewDataSource, UICollectionViewDelegate, UITableViewDataSource, UITableViewDelegate {

    var currentPost: getAdvicePost?
    var imageArray : [UIImage] = []
    var commentArray : [String] = []
    var commentIdArray : [String] = []
    var commentOrderArray : [Int] = []
    var ref: DocumentReference? = nil
    let db = Firestore.firestore()
    
    @IBOutlet weak var titleOutlet: UILabel!
    @IBOutlet weak var occasionOutlet: UILabel!
    @IBOutlet weak var descriptionOutlet: UILabel!
    @IBOutlet weak var imageOutlet: UIImageView!
    @IBOutlet weak var myCollectionView: UICollectionView!
    @IBOutlet weak var myTableView: UITableView!
    @IBOutlet weak var commentOutlet: UITextField!
    @IBOutlet weak var resolvedOutlet: UIButton!
    @IBOutlet weak var postButtonOutlet: UIButton!
    
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return commentArray.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = UITableViewCell(style: .subtitle, reuseIdentifier: "adviceCommentCell")
        cell.textLabel?.text = commentIdArray[indexPath.item] + ": " + commentArray[indexPath.item]
        cell.textLabel?.font = UIFont(name: (cell.textLabel?.font.fontName)!, size: 10)
        cell.textLabel?.numberOfLines = 0
        cell.textLabel?.lineBreakMode = NSLineBreakMode.byWordWrapping
        return cell
    }
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        imageOutlet.image = imageArray[indexPath.item]
    }
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return (currentPost?.imageURLS.count)!
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "adviceDetailCell", for: indexPath)
        let cellImage : UIImageView = UIImageView(frame: CGRect(x: cell.bounds.minX, y: cell.bounds.minY, width: cell.bounds.width, height: cell.bounds.height))
        cellImage.image = imageArray[indexPath.item]
        cell.addSubview(cellImage)
        return cell
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        tableSetup()
        viewSetup()
    }
    
    func tableSetup(){
        myCollectionView.dataSource = self
        myCollectionView.delegate = self
        myTableView.dataSource = self
        myTableView.delegate = self
        myTableView.register(UITableViewCell.self, forCellReuseIdentifier: "adviceCommentCell")
        myTableView.rowHeight = 25
    }
    
    func viewSetup(){
        if currentPost?.resolved == "yes"{
            commentOutlet.isHidden = true
            postButtonOutlet.isHidden = true
            resolvedOutlet.isHidden = true
        } else{
            commentOutlet.isHidden = false
            postButtonOutlet.isHidden = false
            resolvedOutlet.isHidden = false
        }
        titleOutlet.text = currentPost?.title
        occasionOutlet.text = currentPost?.occasion
        if currentPost?.description == ""{
            descriptionOutlet.text = "Description not provided"
            descriptionOutlet.textColor = UIColor.gray
        } else{
            descriptionOutlet.text = currentPost?.description
            descriptionOutlet.textColor = UIColor.black
        }
        if Auth.auth().currentUser?.email == currentPost?.userID && currentPost?.resolved == "no"{
            resolvedOutlet.isHidden = false
        } else{
            resolvedOutlet.isHidden = true
        }
        fetchImages()
        getComments()
    }
    
    func getComments(){
        commentIdArray = []
        commentOrderArray = []
        commentArray = []
        db.collection((currentPost?.postID)!).getDocuments() { (querySnapshot, err) in
            if let err = err {
                print("Error getting documents: \(err)")
            } else {
                DispatchQueue.global().async {
                    for document in querySnapshot!.documents {
                        self.commentIdArray.append(document.data()["userId"] as! String)
                        self.commentArray.append(document.data()["comment"] as! String)
                        self.commentOrderArray.append(document.data()["commentOrder"] as! Int)
                    }
                    self.sortComments()
                    DispatchQueue.main.async {
                        self.myTableView.reloadData()
                    }
                }
            }
        }
    }
    
    func sortComments(){
        var tempIDArray = commentIdArray
        var tempCommentArray = commentArray
        var tempCounter : Int = 0
        for currentOrder in commentOrderArray{
            tempIDArray[commentArray.count - currentOrder] = commentIdArray[tempCounter]
            tempCommentArray[commentArray.count - currentOrder] = commentArray[tempCounter]
            tempCounter = tempCounter + 1
        }
        commentIdArray = tempIDArray
        commentArray = tempCommentArray
    }
    
    
    
    @IBAction func resolvedAction(_ sender: Any) {
        let ref = self.db.collection("advicePost").document((currentPost?.postID)!)
        ref.updateData(["resolved" : "yes"])
        let backVC: getAdviceViewController  = self.storyboard?.instantiateViewController(withIdentifier: "getAdviceView") as! getAdviceViewController
        self.present(backVC, animated: true)
    }
    
    
    @IBAction func commentButtonAction(_ sender: Any) {
        if commentOutlet.text != ""{
            let currentUser : String = (Auth.auth().currentUser?.email)!
            self.ref = self.db.collection((currentPost?.postID)!).document()
            self.ref?.setData([
                "userId": currentUser,
                "comment": commentOutlet.text!,
                "commentOrder": commentArray.count + 1
            ]){ err in
                if let err = err {
                    print("Error adding document: \(err)")
                }
                self.getComments()
                self.commentOutlet.text = ""
            }
        } else{
            let alertUser = UIAlertController(title: "Comment can't be empty!", message: "", preferredStyle: .alert)
            let myAction = UIAlertAction(title: "Ok.", style: .default) { (action:UIAlertAction) in
                return;
            }
            alertUser.addAction(myAction)
            self.present(alertUser, animated: true, completion: nil)
        }
    }
    
    
    @IBAction func backAction(_ sender: Any) {
        let backVC: getAdviceViewController  = self.storyboard?.instantiateViewController(withIdentifier: "getAdviceView") as! getAdviceViewController
        self.present(backVC, animated: true)
    }
    
    func fetchImages(){
        for imageURL in (currentPost?.imageURLS)!{
            do{
                let data = try Data(contentsOf: URL(string: imageURL)!)
                imageArray.append(UIImage(data: data)!)
            } catch{
                print("image error")
            }
        }
        imageOutlet.image = imageArray[0]
        myCollectionView.reloadData()
    }
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        view.endEditing(true)
        super.touchesBegan(touches, with: event)
    }
    
}
