//
//  loginViewController.swift
//  LitFit-Swipe1
//
//  Created by labuser on 7/22/18.
//  Copyright © 2018 David Kwon. All rights reserved.
//

import UIKit
import Firebase
import FirebaseFirestore
import FirebaseStorage
import FirebaseAuth

class loginViewController: UIViewController {

    @IBOutlet var userNameOutlet: UITextField!
    @IBOutlet var userPasswordOutlet: UITextField!
    @IBOutlet weak var spinnerOutlet: UIActivityIndicatorView!
    

    @IBAction func loginAction(_ sender: Any) { //Code based on Firebase documentation
        let email = userNameOutlet.text
        let password = userPasswordOutlet.text
        spinnerOutlet.startAnimating()
        Auth.auth().signIn(withEmail: email!, password: password!) { (user, error) in
            if let error = error {
                let alertUser = UIAlertController(title: error.localizedDescription, message: "", preferredStyle: .alert)
                let myAction = UIAlertAction(title: "Ok.", style: .default) { (action:UIAlertAction) in
                    self.spinnerOutlet.stopAnimating()
                        return;
                }
            alertUser.addAction(myAction)
            self.present(alertUser, animated: true, completion: nil)
            return
            }
            self.spinnerOutlet.stopAnimating()
            let newVC = self.storyboard?.instantiateViewController(withIdentifier: "todaysView")
            self.present(newVC!, animated: true)
        }
    }
    
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        view.endEditing(true)
        super.touchesBegan(touches, with: event)
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
}
