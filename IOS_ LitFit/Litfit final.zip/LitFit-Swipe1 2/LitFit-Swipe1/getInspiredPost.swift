//
//  getInspiredPost.swift
//  LitFit-Swipe1
//
//  Created by labuser on 7/24/18.
//  Copyright © 2018 David Kwon. All rights reserved.
//

import Foundation
import UIKit

struct getInspiredPost {
    let image : UIImage
    let description : String
    let occasion : String
    let likes : Int
    let postID : String
    let userID : String
    let age : Int
    let gender : String
    let addedTime : Date?
}
