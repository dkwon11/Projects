//
//  getAdviceViewController.swift
//  LitFit-Swipe1
//
//  Created by labuser on 7/22/18.
//  Copyright © 2018 David Kwon. All rights reserved.
//

import UIKit
import Firebase
import FirebaseFirestore
import FirebaseStorage
import FirebaseAuth

class getAdviceViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {
    var classArray : [getAdvicePost] = []
    var resolvedClassArray : [getAdvicePost] = []
    let db = Firestore.firestore()
    var resolvedBool : Bool = false
    var filterOccasion : String = "All"
    @IBOutlet weak var resolvedOutlet: UIButton!
    @IBOutlet weak var filterTextOutlet: UILabel!
    @IBOutlet weak var spinnerOutlet: UIActivityIndicatorView!
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let detailedVC: getAdviceDetailedViewController  = storyboard?.instantiateViewController(withIdentifier: "getAdviceDetailed") as! getAdviceDetailedViewController
        if resolvedBool{
            detailedVC.currentPost = resolvedClassArray[indexPath.item]
        } else{
            detailedVC.currentPost = classArray[indexPath.item]
        }
        self.present(detailedVC, animated: true)
    }
    
    @IBAction func backAction(_ sender: Any) {
        let backVC: TodaysFitViewController  = self.storyboard?.instantiateViewController(withIdentifier: "todaysView") as! TodaysFitViewController
        self.present(backVC, animated: true)
    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if resolvedBool{
            return resolvedClassArray.count
        } else{
            return classArray.count
        }
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = UITableViewCell(style: .subtitle, reuseIdentifier: "adviceCell")
        if resolvedBool{
            cell.textLabel?.text = resolvedClassArray[indexPath.item].title
            cell.detailTextLabel?.text = resolvedClassArray[indexPath.item].occasion
            cell.imageView?.image = resolvedClassArray[indexPath.item].image
            if resolvedClassArray[indexPath.item].userID == Auth.auth().currentUser?.email{
                cell.backgroundColor = #colorLiteral(red: 0.9694538713, green: 0.9506332278, blue: 0.9116199613, alpha: 1)
            }
        } else{
            cell.textLabel?.text = classArray[indexPath.item].title
            cell.detailTextLabel?.text = classArray[indexPath.item].occasion
            cell.imageView?.image = classArray[indexPath.item].image
            if classArray[indexPath.item].userID == Auth.auth().currentUser?.email{
                cell.backgroundColor = #colorLiteral(red: 0.9694538713, green: 0.9506332278, blue: 0.9116199613, alpha: 1)
            }
        }
        return cell
    }
    
    @IBAction func filterAction(_ sender: Any) {
        let alertUser = UIAlertController(title: "Select Occasion", message: "", preferredStyle: .alert)
        let action1 = UIAlertAction(title: "Casual", style: .default) { (action:UIAlertAction) in
            self.filterOccasion = "Casual";
            self.getData()
        }
        let action2 = UIAlertAction(title: "Night Out", style: .default) { (action:UIAlertAction) in
            self.filterOccasion = "Night Out";
            self.getData();
        }
        let action3 = UIAlertAction(title: "Job Interview", style: .default) { (action:UIAlertAction) in
            self.filterOccasion = "Job Interview";
            self.getData();
        }
        let action4 = UIAlertAction(title: "Business Casual", style: .default) { (action:UIAlertAction) in
            self.filterOccasion = "Business Casual";
            self.getData();
        }
        let action5 = UIAlertAction(title: "Formal", style: .default) { (action:UIAlertAction) in
            self.filterOccasion = "Formal";
            self.getData();
        }
        let action6 = UIAlertAction(title: "Streetwear", style: .default) { (action:UIAlertAction) in
            self.filterOccasion = "Streetwear";
            self.getData();
        }
        let action7 = UIAlertAction(title: "All", style: .default) { (action:UIAlertAction) in
            self.filterOccasion = "All";
            self.getData();
        }

        alertUser.addAction(action7)
        alertUser.addAction(action1)
        alertUser.addAction(action2)
        alertUser.addAction(action3)
        alertUser.addAction(action4)
        alertUser.addAction(action5)
        alertUser.addAction(action6)
        self.present(alertUser, animated: true, completion: nil)
    }
    
    
    @IBAction func viewResolvedAction(_ sender: Any) {
        if resolvedOutlet.titleLabel?.text == "View Resolved"{
            resolvedBool = true
            resolvedOutlet.setTitle("View Unresolved", for: UIControlState.normal)
        } else{
            resolvedBool = false
            resolvedOutlet.setTitle("View Resolved", for: UIControlState.normal)
        }
        getData()
    }
    
    
    @IBOutlet weak var myTableView: UITableView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        myTableView.delegate = self
        myTableView.dataSource = self
        myTableView.register(UITableViewCell.self, forCellReuseIdentifier: "adviceCell")
    }
    
    func getData(){
        classArray = []
        resolvedClassArray = []
        if filterOccasion == "All"{
            filterTextOutlet.text = ""
        } else{
            filterTextOutlet.text = filterOccasion
        }
        db.collection("advicePost").getDocuments() { (querySnapshot, err) in
            if let err = err {
                print("Error getting documents: \(err)")
            } else {
                self.spinnerOutlet.startAnimating()
                DispatchQueue.global().async {
                    for document in querySnapshot!.documents {
                        let tempTitle = document.data()["title"] as! String
                        let tempOccasion = document.data()["occasion"] as! String
                        let dbImage = document.data()["images"] as! [String]
                        let tempPostId = document.data()["postID"] as! String
                        let tempUserId = document.data()["userId"] as! String
                        let tempDescription = document.data()["description"] as! String
                        let tempResolved = document.data()["resolved"] as! String
                        let tempAddedTime = document.data()["timeStamp"] as! Date
                        var firstImageURL : String = ""
                        do {
                            for checkURL in dbImage{
                                let jpegIndex = checkURL.index(of: "?")
                                let imageIndex = checkURL.index(jpegIndex!, offsetBy: -5)
                                if checkURL[imageIndex] == "0"{
                                    firstImageURL = checkURL
                                    break
                                }
                            }
                            let url = URL(string: firstImageURL)
                            let data = try Data(contentsOf: url!)
                            let tempImage = UIImage(data: data)!
                            let tempPost = getAdvicePost(image: tempImage, title: tempTitle, description: tempDescription, occasion: tempOccasion, postID: tempPostId, userID: tempUserId, resolved: tempResolved, imageURLS: dbImage, addedTime: tempAddedTime )
                            if tempResolved == "no" {
                                if self.filterOccasion == "All" || self.filterOccasion == tempOccasion{
                                    self.classArray.append(tempPost)
                                }
                            } else{
                                if self.filterOccasion == "All" || self.filterOccasion == tempOccasion{
                                    self.resolvedClassArray.append(tempPost)
                                }
                            }
                        }
                        catch{
                            print("image error")
                        }
                    }
                    DispatchQueue.main.async {
                        self.spinnerOutlet.stopAnimating()
                        self.classArray = self.classArray.sorted(by: { $0.addedTime! > $1.addedTime! })
                        self.resolvedClassArray = self.resolvedClassArray.sorted(by: { $0.addedTime! > $1.addedTime! })
                        self.myTableView.reloadData()
                    }
                }
            }
        }
    }
    
    override func viewWillAppear(_ animated: Bool) {
        resolvedBool = false
        filterOccasion = "All"
        filterTextOutlet.text = ""
        resolvedOutlet.setTitle("View Resolved", for: UIControlState.normal)
        getData()
    }

    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        view.endEditing(true)
        super.touchesBegan(touches, with: event)
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
}
